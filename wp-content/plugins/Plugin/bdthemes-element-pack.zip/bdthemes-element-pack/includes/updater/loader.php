<?php

require __DIR__ . '/src/V1/PluginUpdater.php';