<?php
/**
 * Template Library Modal Header
 */
?>
<span class="premium-template-modal-header-logo-icon">
    <img src="<?php echo PREMIUM_ADDONS_URL .'admin/images/premium-addons-logo.png'; ?>">
</span>
<span class="premium-template-modal-header-logo-label">
    <?php echo __('Premium Templates', 'premium-addons-for-elementor'); ?>
</span>

