
 ### v1.1.6 - 2018-12-10 
 **Changes:** 
 * Tested with WP 5.0
 
 ### v1.1.5 - 2018-11-29 
 **Changes:** 
 * Fix possible issue with multiple notices
 
 ### v1.1.4 - 2018-11-27 
 **Changes:** 
 * Fixed version
 
 ### v1.1.3 - 2018-11-27 
 **Changes:** 
 * Add notice for recommended theme
 
 ### v1.1.2 - 2017-11-27 
 **Changes:** 
 * Fix TGM strings for recommended plugins.
 
 ### v1.1.1 - 2017-11-16 
 **Changes:** 
 * Add recommendation for Elementor Addons & Widgets. 
* Tested up to 4.9.
 
 ### v1.1.0 - 2017-09-28 
 **Changes:** 
 * Added Themeisle SDK.
* Added Continuous Integration.
* Changed contributors.
 
