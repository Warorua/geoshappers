<div class="sina-ext-toggle">
	<?php printf('<input type="checkbox" id="%s" name="%s" %s value="1">', $name, $key, $checked); ?>
	<?php printf('<label for="%s"><div></div></label>', $name); ?>
</div>